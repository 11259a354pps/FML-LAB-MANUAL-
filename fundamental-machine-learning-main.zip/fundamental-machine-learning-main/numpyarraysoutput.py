PS C:\Users\sathw\OneDrive\Desktop\FML GITHUB CODE> python numpyarrays.py
<module 'numpy.version' from 'C:\\Users\\sathw\\AppData\\Local\\Packages\\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\\LocalCache\\local-packages\\Python313\\site-packages\\numpy\\version.py'>
[2 3 4 5]
[[2 3 4 5]
 [6 7 8 9]]
[[[ 0  1]
  [ 2  3]
  [ 4  5]]

 [[ 6  7]
  [ 8  9]
  [10 11]]

 [[12 13]
  [14 15]
  [16 17]]

 [[18 19]
  [20 21]
  [22 23]]]
[2]
[1 2 3]
[1 3]
[ 0.         -0.98803162 -0.30481062  0.89399666]
[ 1.          0.15425145 -0.95241298 -0.44807362]
[ 0.         -6.4053312   0.32004039 -1.99520041]
Original List: [12.23, 13.32, 100, 36.32]
One-dimensional NumPy array:  [ 12.23  13.32 100.    36.32]
[12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
 36 37]
Original array:
[12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
 36 37]
Reverse array:
[37 36 35 34 33 32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14
 13 12]
Original array:
[10, 20, 30]
After append values to the end of the array:
[10 20 30 40 50 60 70 80 90]
Array1:  [ 0 10 20 40 60]
Array2:  [10, 30, 40]
Common values between two arrays:
[10 40]
Array1:  [ 0 10 20 40 60 80]
Array2:  [10, 30, 40, 50, 70]
Unique sorted array of values that are in either of the two input arrays:
[ 0 10 20 30 40 50 60 70 80]
[[ 0  1  3  0  2  4]
 [ 5  7  9  6  8 10]]
Values in Fahrenheit degrees:
[ 0.   12.   45.21 34.   99.91 32.  ]
Values in Centigrade degrees:
[-17.78 -11.11   7.34   1.11  37.73   0.  ]
Values in Centigrade degrees:
[-17.78 -11.11   7.34   1.11  37.73   0.  ]
Values in Fahrenheit degrees:
[-0.   12.   45.21 34.   99.91 32.  ]
First Array:
[[0. 1. 2.]
 [3. 4. 5.]
 [6. 7. 8.]]
Second Array:
[10 20 30]
Addition of Arrays:
[[10. 21. 32.]
 [13. 24. 35.]
 [16. 27. 38.]]
Subtraction of Arrays:
[[-10. -19. -28.]
 [ -7. -16. -25.]
 [ -4. -13. -22.]]
Multiplication of Arrays:
[[  0.  20.  60.]
 [ 30.  80. 150.]
 [ 60. 140. 240.]]
Division of Arrays:
[[0.         0.05       0.06666667]
 [0.3        0.2        0.16666667]
 [0.6        0.35       0.26666667]]