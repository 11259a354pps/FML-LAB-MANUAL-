# K-Means Clustering using Iris Dataset

from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

# --------------------------------------------------
# Step 1: Load Iris Dataset
# --------------------------------------------------

iris = load_iris()

X = iris.data
y = iris.target

print("Dataset Shape:", X.shape)
print("Number of Samples:", X.shape[0])
print("Number of Features:", X.shape[1])

print("\nFeatures:")
print(iris.feature_names)

# --------------------------------------------------
# Step 2: Feature Scaling
# --------------------------------------------------

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# --------------------------------------------------
# Step 3: Create K-Means Model
# --------------------------------------------------

kmeans = KMeans(
    n_clusters=3,
    random_state=42,
    n_init=10
)

# --------------------------------------------------
# Step 4: Fit K-Means Model
# --------------------------------------------------

kmeans.fit(X_scaled)

# --------------------------------------------------
# Step 5: Get Cluster Labels
# --------------------------------------------------

labels = kmeans.labels_

# --------------------------------------------------
# Step 6: Get Cluster Centroids
# --------------------------------------------------

centroids = kmeans.cluster_centers_

# --------------------------------------------------
# Step 7: Display Results
# --------------------------------------------------

print("\nCluster Labels:")
print(labels)

print("\nCluster Centroids:")
print(centroids)

# --------------------------------------------------
# Step 8: Calculate Silhouette Score
# --------------------------------------------------

silhouette = silhouette_score(X_scaled, labels)

print("\nCluster Evaluation")
print("------------------")
print("Silhouette Score:",
      round(silhouette, 4))

# --------------------------------------------------
# Step 9: Display Cluster Count
# --------------------------------------------------

print("\nNumber of Samples in Each Cluster:")

for i in range(3):
    print(
        "Cluster", i,
        ":",
        sum(labels == i),
        "samples"
    )

# --------------------------------------------------
# Step 10: Visualize Clusters
# --------------------------------------------------

plt.figure(figsize=(8, 6))

plt.scatter(
    X_scaled[:, 2],
    X_scaled[:, 3],
    c=labels
)

plt.scatter(
    centroids[:, 2],
    centroids[:, 3],
    marker='X',
    s=200
)

plt.xlabel("Petal Length")
plt.ylabel("Petal Width")
plt.title("K-Means Clustering on Iris Dataset")

plt.show()