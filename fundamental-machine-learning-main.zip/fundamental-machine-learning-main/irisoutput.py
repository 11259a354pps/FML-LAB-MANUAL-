Dataset Shape: (150, 4)
Number of Samples: 150
Number of Features: 4
Target Classes: ['setosa' 'versicolor' 'virginica']

Dataset Splitting
-----------------
Training samples: 120
Testing samples : 30

Test Set Performance
--------------------
Test Accuracy: 0.9667

5-Fold Cross-Validation
-----------------------
Fold 1 Accuracy: 1.0
Fold 2 Accuracy: 1.0
Fold 3 Accuracy: 0.9333
Fold 4 Accuracy: 0.9667
Fold 5 Accuracy: 0.9667

Cross-Validation Results
------------------------
Average Accuracy: 0.9733
Standard Deviation: 0.0249