PS C:\Users\sathw\OneDrive\Desktop\FML GITHUB CODE> python knn.py
Dataset Shape: (150, 4)
Number of Samples: 150
Number of Features: 4
Target Classes: ['setosa' 'versicolor' 'virginica']

Dataset Splitting
-----------------
Training samples: 120
Testing samples : 30

KNN Model Evaluation
--------------------
Accuracy : 0.9333
Precision: 0.9444
Recall   : 0.9333
F1-Score : 0.9327

Confusion Matrix
----------------
[[10  0  0]
 [ 0 10  0]
 [ 0  2  8]]