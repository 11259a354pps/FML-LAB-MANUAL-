# SVM Classification using Iris Dataset

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_score,
    recall_score,
    f1_score
)

# --------------------------------------------------
# Step 1: Load Iris Dataset
# --------------------------------------------------

iris = load_iris()

X = iris.data
y = iris.target

print("Dataset Shape:", X.shape)
print("Number of Samples:", len(X))
print("Number of Features:", X.shape[1])
print("Target Classes:", iris.target_names)

# --------------------------------------------------
# Step 2: Split Dataset
# --------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nDataset Splitting")
print("-----------------")
print("Training samples:", len(X_train))
print("Testing samples :", len(X_test))

# --------------------------------------------------
# Step 3: Feature Scaling
# --------------------------------------------------

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# --------------------------------------------------
# Step 4: Create SVM Model
# --------------------------------------------------

model = SVC(
    kernel='linear',
    C=1.0
)

# --------------------------------------------------
# Step 5: Train the Model
# --------------------------------------------------

model.fit(X_train, y_train)

# --------------------------------------------------
# Step 6: Make Predictions
# --------------------------------------------------

y_pred = model.predict(X_test)

# --------------------------------------------------
# Step 7: Calculate Evaluation Metrics
# --------------------------------------------------

accuracy = accuracy_score(y_test, y_pred)

cm = confusion_matrix(y_test, y_pred)

precision = precision_score(
    y_test,
    y_pred,
    average='weighted'
)

recall = recall_score(
    y_test,
    y_pred,
    average='weighted'
)

f1 = f1_score(
    y_test,
    y_pred,
    average='weighted'
)

# --------------------------------------------------
# Step 8: Display Results
# --------------------------------------------------

print("\nSVM Model Evaluation")
print("--------------------")

print("Accuracy :", round(accuracy, 4))
print("Precision:", round(precision, 4))
print("Recall   :", round(recall, 4))
print("F1-Score :", round(f1, 4))

print("\nConfusion Matrix")
print("----------------")
print(cm)