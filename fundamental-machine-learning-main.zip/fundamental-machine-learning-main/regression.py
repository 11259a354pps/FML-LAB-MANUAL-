# Linear Regression using Iris Dataset

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np

# -------------------------------------------------
# Step 1: Load Iris Dataset
# -------------------------------------------------

iris = load_iris()

X = iris.data
feature_names = iris.feature_names

# Predict Petal Length
# Column 2 = Petal Length
y = iris.data[:, 2]

# Use Sepal Length, Sepal Width and Petal Width
# as input features
X = iris.data[:, [0, 1, 3]]

print("Features:")
print(feature_names)

print("\nDataset Shape:", X.shape)
print("Target Shape:", y.shape)

# -------------------------------------------------
# Step 2: Split Dataset
# -------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)

print("\nTraining Samples:", len(X_train))
print("Testing Samples :", len(X_test))

# -------------------------------------------------
# Step 3: Create Linear Regression Model
# -------------------------------------------------

model = LinearRegression()

# -------------------------------------------------
# Step 4: Train the Model
# -------------------------------------------------

model.fit(X_train, y_train)

# -------------------------------------------------
# Step 5: Make Predictions
# -------------------------------------------------

y_pred = model.predict(X_test)

# -------------------------------------------------
# Step 6: Display Predictions
# -------------------------------------------------

print("\nActual vs Predicted Values")
print("--------------------------------")

for actual, predicted in zip(y_test[:10], y_pred[:10]):
    print("Actual:", round(actual, 2),
          " Predicted:", round(predicted, 2))

# -------------------------------------------------
# Step 7: Evaluate the Model
# -------------------------------------------------

mse = mean_squared_error(y_test, y_pred)

rmse = np.sqrt(mse)

mae = mean_absolute_error(y_test, y_pred)

r2 = r2_score(y_test, y_pred)

print("\nModel Evaluation")
print("-----------------------------")
print("Mean Squared Error (MSE):", round(mse, 4))
print("Root Mean Squared Error (RMSE):", round(rmse, 4))
print("Mean Absolute Error (MAE):", round(mae, 4))
print("R2 Score:", round(r2, 4))

# -------------------------------------------------
# Step 8: Display Model Coefficients
# -------------------------------------------------

print("\nModel Coefficients")
print("-----------------------------")

for name, coefficient in zip(
        ["Sepal Length", "Sepal Width", "Petal Width"],
        model.coef_):

    print(name, ":", round(coefficient, 4))

print("Intercept:", round(model.intercept_, 4))
