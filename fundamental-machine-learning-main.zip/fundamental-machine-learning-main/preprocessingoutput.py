First 5 Records
   Id  SepalLengthCm  SepalWidthCm  PetalLengthCm  PetalWidthCm        Species
0   1      5.1             3.5            1.4           0.2      Iris-setosa
1   2      4.9             3.0            1.4           0.2      Iris-setosa
2   3      4.7             3.2            1.3           0.2      Iris-setosa
3   4      4.6             3.1            1.5           0.2      Iris-setosa
4   5      5.0             3.6            1.4           0.2      Iris-setosa


